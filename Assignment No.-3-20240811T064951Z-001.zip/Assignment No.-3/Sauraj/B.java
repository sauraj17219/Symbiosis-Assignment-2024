package first;

public class B extends A {
    public static void main(String[] args) {
        B obj=new B();
        obj.displayOdd();
        System.out.println("Addition of odd numbers: "+obj.calcOddAdd());
    }
}
